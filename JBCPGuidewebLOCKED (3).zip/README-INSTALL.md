# JBC-P / BFT-2 Field Guide — password-locked, offline

This bundle is encrypted with AES-256. On open it shows a lock screen and asks
for your password. Without the correct password the files are unreadable
ciphertext — the content cannot be viewed and its source cannot be traced.

- 🔒 Encrypted content — nothing readable in the code
- ✅ Live Zulu clock, correct layout, saved progress (after unlock)
- ✅ 100% offline once installed — decryption happens on your device
- ⚠️ No password recovery. If the password is lost, the content is gone. Keep it safe.

## Install on iPhone (no computer needed)

1. Save this ZIP to Files (Share → Save to Files → On My iPhone).
2. In **Safari**, upload the ZIP to a free HTML host that accepts a ZIP
   (e.g. static.app or tiiny.host). It gives you a link.
3. Open the link in **Safari** → you'll see the lock screen.
4. Tap **Share → Add to Home Screen → Add**.
5. Tap the JBC-P icon, enter your password, and you're in. Works with no signal.
   The link is never needed again.

> Must be uploaded as a ZIP/folder (not a single file) so `sw.js` sits next to
> `index.html` — that's what makes it work offline. Also: unlock needs a secure
> context (the installed app or an https link), which the steps above give you.

## Files (keep together)
- `index.html` — encrypted app + lock screen
- `sw.js` — offline cache
- `manifest.json`, `icon-192.png`, `icon-512.png` — app name + icons
